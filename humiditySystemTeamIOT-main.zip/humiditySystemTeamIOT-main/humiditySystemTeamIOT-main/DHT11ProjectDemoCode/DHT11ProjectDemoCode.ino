
#include "DHT.h"
#include <LiquidCrystal.h>
#define DHTPIN 2    

#define DHTTYPE DHT11   // DHT 11
#include <Wire.h>
#include "rgb_lcd.h"

rgb_lcd lcd;

const int colorR = 0;
const int colorG = 255;
const int colorB = 0;

const int buttonPin = 3;
int buttonState = 0;


DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  Serial.println(F("DHTxx test!"));
  lcd.begin(16, 2);
  lcd.setRGB(colorR, colorG, colorB);

  pinMode(buttonPin, INPUT);

  dht.begin();
}

void loop() {
  // Wait a few seconds between measurements.
  delay(2000);


  float h = dht.readHumidity();
  // Read temperature as Celsius (the default)
  float t = dht.readTemperature();



  

  // Check if any reads failed and exit early (to try again).
  if (isnan(h) || isnan(t)) {
    Serial.println(F("Failed to read from DHT sensor!"));
    lcd.clear();
    lcd.setCursor(0, 1);
    lcd.print("Failed to read!");
    return;
  }


  Serial.print(F("Humidity: "));
  Serial.print(h);
  Serial.println("%");
  Serial.print(F("Temperature: "));
  Serial.print(t);
  Serial.println(F("°C "));

// Use button to get Mold Reading when held
  buttonState = digitalRead(buttonPin);

  if (buttonState == LOW)
  {
  lcd.clear();
    //Display Humidity and Temp
  lcd.setCursor(0, 0);
  lcd.print("Humidity: ");
  lcd.print(h);
  lcd.print("%");

  lcd.setCursor(0, 1);
  lcd.print("Temp: ");
  lcd.print(t);
  lcd.print((char)223);
  lcd.print("C");

  }
  else
  {
    //Display Mold
    MoldRisk(h,t);
  }
  delay(100);
}

void MoldRisk(float humidity, float temp){
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Mold Risk:");
  //HIGH RISK
  if(humidity >= 60 || (temp >= 30 && temp <= 25))
  {
    bool h = humidity >= 60;
    bool t = (temp <= 30 && temp >= 25);
    lcd.print("High");
    if(h && t)
    {
      lcd.setCursor(0, 1);
      lcd.print("T and H:");
    }
    else if(h)
    {  
      lcd.setCursor(0, 1);
      lcd.print("H of:");
      lcd.print(humidity);
    }
    else if(t)
    {
      lcd.setCursor(0, 1);
      lcd.print("T of:");
      lcd.print(temp);
    }
  }
  //LOW
  else if((humidity >= 25 && humidity <=30) && (temp <= 30 && temp >= 25))
  {
    lcd.print("Low");
    lcd.setCursor(0, 1);
    lcd.print("Perfect T+H");
  }
  //NORMAL
  else
  {
    lcd.print("Normal");
  } 
}

